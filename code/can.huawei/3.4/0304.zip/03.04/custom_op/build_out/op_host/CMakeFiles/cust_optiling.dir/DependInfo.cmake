
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/workspace/notebook2/cann-learning-hub/tutorials/ascendc_operator_development/03_intermediate_vector_operator_development/Sources/03.04/custom_op/op_host/add_custom_template.cpp" "op_host/CMakeFiles/cust_optiling.dir/add_custom_template.cpp.o" "gcc" "op_host/CMakeFiles/cust_optiling.dir/add_custom_template.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
