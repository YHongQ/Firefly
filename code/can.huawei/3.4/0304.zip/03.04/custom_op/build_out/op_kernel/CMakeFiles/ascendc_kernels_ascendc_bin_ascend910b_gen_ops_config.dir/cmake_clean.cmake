file(REMOVE_RECURSE
  "CMakeFiles/ascendc_kernels_ascendc_bin_ascend910b_gen_ops_config"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/ascendc_kernels_ascendc_bin_ascend910b_gen_ops_config.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
