# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for ascendc_kernels_copy_kernel_srcs.
